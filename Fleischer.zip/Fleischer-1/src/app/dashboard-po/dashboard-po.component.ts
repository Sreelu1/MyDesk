import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-po',
  templateUrl: './dashboard-po.component.html',
  styleUrls: ['./dashboard-po.component.css']
})
export class DashboardPoComponent implements OnInit {

  constructor() { 
   
  }

  ngOnInit() {
  }

}
